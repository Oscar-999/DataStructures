///Oscar Alcantar
//Homework0501
//Description: Workingg with Linked Lists adding del


#ifndef LLNODE_H
#define LLNODE_H



class LLNode {
public:
    int data; // actual data in the node
    LLNode* next; // pointer

    //constructor
    LLNode(int val);

};



#endif //LLNODE_H
