//Oscar Alcantar
//Homework0501
//Description: Workingg with Linked Lists


#include "LLNode.h"

LLNode::LLNode(int val) {
    data = val; // the data field is the value entered
    next = nullptr; // setting next to nullptr by def
}

